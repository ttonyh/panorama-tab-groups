export default function resetPTG() {
  window.alert('Not implemented yet');
}
